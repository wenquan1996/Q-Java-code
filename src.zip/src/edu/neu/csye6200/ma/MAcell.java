package edu.neu.csye6200.ma;
/**
 * @author Quan Wen
 * NUID:001497206
 */
public class MAcell {
	int a;
	

	public MAcell() {
		// TODO Auto-generated constructor stub
		this.a=0;
		
	}

	public int getA() {
		return a;
	}
   

	public void setA(int a) {
		
		
		this.a = a;
	}
	
}
